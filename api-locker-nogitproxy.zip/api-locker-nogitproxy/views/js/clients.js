$('#filter-elems').click(() => {

  var data = {
    name: $('#input-nameclient').val(),
    profile: $('#input-profileclient').val(),
  };

  filterElems(data, 'clients');
});
