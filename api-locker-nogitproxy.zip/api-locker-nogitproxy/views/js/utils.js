$('#refreshpage').click(() => {
  location.reload();
});

// random Numbers
var random = function random() {
  return Math.round(Math.random() * 100);
}; // eslint-disable-next-line no-unused-vars

var filterElems = function(data, url, tableId) {
  if (!tableId)
    tableId = '#tableelems';

  $.ajax({
    type: 'POST',
    url: url,
    data: data,
    success: function(response) {
      if (response.indexOf('<!DOCTYPE html>') == 0)
        window.location.replace('login')
      else
        $(tableId).html(response);
      console.log('success filter');
    },
    error: function(error) {
      console.log('error filter');
    }
  });
}

var deleteElemUrl = function(event, url, tableId) {
  if (!tableId)
    tableId = '#tableelems';
  var id = event.target.getAttribute('idelem');

  $.ajax({
    type: 'DELETE',
    url: url,
    data: {
      id: id
    },
    success: function(response) {
      if (response && response.affectedRows == 1) {
        var registers = $(tableId)[0].children.forEach(register => {
          if (register.children && register.children.length > 0) {
            var currentIdelem = register.children[0].children[0].attributes.idelem.value;
            if (id == currentIdelem)
              register.innerHTML='';
          }
        });
      }
      console.log('success delete');
    },
    error: function(error) {
      console.log('error delete');
    }
  });
}

$('#input-group').keyup(function(e){
  if(e.keyCode == 13)
    $('#filter-elems').click();
});
