$('#filter-elems').click(() => {

  var data = {
    appname: $('#input-appname').val(),
    parameters: $('#input-parameters').val(),
    type: $('#input-type').val(),
    response: $('#input-response').val(),
    datestart: $('#input-datestart').val(),
    dateend: $('#input-dateend').val()
  };

  filterElems(data, 'requests');
});

var deleteRequest = function(event) {
  deleteElemUrl(event, 'api/requests');
};
