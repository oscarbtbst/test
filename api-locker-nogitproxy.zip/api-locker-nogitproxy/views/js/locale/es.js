const jsonEsTranslation =
{
  login: {
    login: "Iniciar sesión",
    login_btn: "Entrar",
    sign_in: "Entrada en tu cuenta",
    username: "Usuario",
    password: "Contraseña"
  },
  clients: {
    title: "Conexiones",
    client_name: "Nombre",
    profile: "Perfil",
    token: "Token",
    useLDAP: "Usar LDAP"
  },
  configs: {
    title: "Configuración",
    key: "Clave",
    value: "Valor"
  },
  common: {
    date: "Fecha",
    filter: "Filtro",
    name: "Nombre",
    full_name: "Nombre Completo",
    description: "Descripción",
    actions: "Acciones",
    date_start: "Fecha Inicio",
    date_end: "Fecha Final",
    close: "Cerrar",
    add: "Añadir",
    save: "Guardar",
    previous: "Anterior",
    next: "Siguiente",
    place: "Lugar",
    definition: "Definición",
    desc_locker: "Descripción Locker",
    desc_corner: "Descripción Corner",
  },
  confirm: {
    confirmation: "Confirmación",
    are_you_sure_delete: "¿Estas seguro de querer eliminar?",
    are_you_sure_unblock: "¿Estas seguro de querer desbloquear?",
    yes: "Si",
    no: "No"
  },
  profiles: {
    Admin: "Administrador",
    Manager: "Gestor",
    Technician: "Técnico",
    User: "Usuario",
    Customer: "Cliente",
    Reader: "Lector"
  },
  colors: ['#A7414A', '#6A8A82', '#906D23', '#563838', '#525B6', '#B39063',
    '#0294A5', '#A4978E', '#03353E', '#A79C93', '#C1403D']
}

//Only exports if code is executed on browser
var navigator;
if (!navigator)
  module.exports = function() {
    return jsonEsTranslation;
  }
