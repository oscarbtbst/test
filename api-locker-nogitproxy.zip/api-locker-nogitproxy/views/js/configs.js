$('#filter-elems').click(() => {

  var data = {
    key: $('#input-key').val(),
    value: $('#input-value').val()
  };

  filterElems(data, 'configs');
});
