$('#login-user').click(() => {

  var data = {
    name: $('#input-name').val(),
    password: $('#input-password').val()
  };

  $.ajax({
    type: 'POST',
    url: 'api/clients/login',
    data: data,
    success: function(response) {
      if (response.token)
        window.location.replace('');
      console.log('success login');
    },
    error: function(error) {
      console.log('error login');
    }
  });
});

$('.input-group').keyup(function(e){
  if(e.keyCode == 13)
    $('#login-user').click();
});
