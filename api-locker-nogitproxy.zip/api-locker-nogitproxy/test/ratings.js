let chai = require('chai');
let chaiHttp = require('chai-http');
const expect = require('chai').expect;

chai.use(chaiHttp);
const url= 'http://localhost:8080';
var token, id;

describe('Login client: ',()=>{

  it('should login client test', (done) => {
    chai.request(url)
      .get('/api/clients/login')
      .send({name: 'test', password: 'test'})
      .end( function(err,res){
        console.log(res.body);
        if (res.body.token)
          token = res.body.token;
        expect(res).to.have.status(200);
        done();
      });
  });
});

describe('Publish rating: ',()=>{

  it('should publish rating from client test', (done) => {

    var body = {
      user: 'user1',
      appName: 'miOficina',
      version: '1.0',
      value: 2,
      comment: 'Comentario de prueba',
      token: token
    }

    chai.request(url)
      .post('/api/ratings')
      .send(body)
      .end( function(err,res){
        console.log(res.body);
        expect(res).to.have.status(200);
        done();
      });
  });
});

describe('Get ratings client: ',()=>{

  it('should get posts from user test', (done) => {

    var selector = {
      token: token,
      appName: 'miOficina',
      version: '1.0',
      last: 2
    };

    chai.request(url)
      .get('/api/ratings')
      .send(selector)
      .end( function(err,res){
        console.log(res.body);
        id = res.body[0].id;
        expect(res).to.have.status(200);
        done();
      });
  });
});

describe('Delete rating: ',()=>{

  it('should delete rating from client test', (done) => {

    var selector = {
      token: token,
      id: id
    }

    chai.request(url)
      .delete('/api/ratings')
      .send(selector)
      .end( function(err,res){
        console.log(res.body);
        expect(res).to.have.status(200);
        done();
      });
  });
});

describe('Logout client: ',()=>{

  it('should logout client test', (done) => {
    chai.request(url)
      .get('/api/clients/logout')
      .send({token: token})
      .end( function(err,res){
        console.log(res.body);
        expect(res).to.have.status(200);
        done();
      });
  });
});
