const express = require('express');
const routesApiClients = require('./routes/api/clients');
const routesApiRequests = require('./routes/api/requests');
const routesApiElements = require('./routes/api/elements');
const routesApiConfigs = require('./routes/api/configs');
const routesWebsockets = require('./routes/api/websockets');
const routesApi = require('./routes/api');
const routes = require('./routes');
const routesConfigs = require('./routes/configs');
const http = require('http');
const path = require('path');
const crypto = require('crypto');
const moment = require('moment');
const pjson = require('./package.json');

const favicon = require('serve-favicon'),
  logger = require('morgan'),
  bodyParser = require('body-parser'),
  methodOverride = require('method-override'),
  cookieParser = require('cookie-parser'),
  session = require('express-session'),
  csrf = require('csurf'),
  errorHandler = require('errorhandler');

const SequelizeStore = require('connect-session-sequelize')(session.Store);
const modelMySQL = require('./model/mySQL');
const modelCore = require('./model/core');

const app = express();


app.use(function(req, res, next) {
  req.db = {};
  req.crypto = crypto;

  req.db.Clients = modelCore.dbclients;
  req.db.Requests = modelCore.dbrequests;
  req.db.Sessions = modelCore.dbsessions;
  req.db.Configs = modelCore.dbconfigs;

  next();
})
app.locals.appname = 'Express.js Locker App';
app.locals.moment = require('moment');

app.set('port', process.env.PORT || 3000);
app.set('views', __dirname + '/views');
app.set('view engine', 'jade');
app.use(favicon(path.join('public','favicon.ico')));
logger.token('momentdate', function(req, res) { return moment().format('DD/MM/YYYY HH:mm:ss') })
app.use(logger('[:momentdate][WEB] :remote-addr :method :url :status :res[content-length] :response-time ms'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
app.use(methodOverride());
app.use(cookieParser('CEAF3FA4-F385-49AA-8FE4-54766A9874F1'));
app.use(session({
  secret: '59B93087-78BC-4EB9-993A-A61FC844F6C9',
  store: new SequelizeStore({db: modelMySQL.sequelize}),
  resave: false,
  saveUninitialized: false
}));

app.use(require('less-middleware')(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname, 'public')));

app.use('/node_modules', express.static(__dirname + '/node_modules'));
app.use('/img', express.static(__dirname + '/views/img'));
app.use('/css', express.static(__dirname + '/views/css'));
app.use('/js', express.static(__dirname + '/views/js'));
app.use('/vendors', express.static(__dirname + '/views/vendors'));

//Web
app.get('/', routes.index);
app.post('/', routes.index);
app.get('/requests', routes.index);
app.post('/requests', routes.index);
app.get('/clients', routes.clients);
app.post('/clients', routes.clients);
app.get('/configs', routesConfigs.configs);
app.post('/configs', routesConfigs.configs);
app.get('/login', routes.login);
app.get('/logout', routes.logout);

//API
app.get('/sessions', routesApi.sessions);
app.get('/api', routesApi.api);

app.get('/api/websocket', routesWebsockets.apiGet);
app.put('/api/websocket', routesWebsockets.apiPut);
app.delete('/api/websocket', routesWebsockets.apiDelete);
app.get('/api/websocket/actioncable', routesWebsockets.apiGetActioncable);
app.delete('/api/websocket/actioncable', routesWebsockets.apiDeleteActioncable);
app.get('/api/websocket/logs', routesWebsockets.apiLogsWebsocket);
app.put('/api/websocket/message', routesWebsockets.apiMessageWebsocket);
app.put('/api/websocket/subscribe', routesWebsockets.apiSubscribeWebsocket);

app.get('/api/configs', routesApiConfigs.apiGetConfigs);
app.put('/api/configs', routesApiConfigs.apiPutConfigs);

app.post('/api/clients/register', routesApiClients.apiRegister);
app.post('/api/clients/login', routesApiClients.apiLogin);
app.get('/api/clients/login', routesApiClients.apiLogin);
app.get('/api/clients/logout', routesApiClients.apiLogout);
app.put('/api/clients/token', routesApiClients.apiToken);

app.post('/api/requests', routesApiRequests.apiPost);
app.get('/api/requests', routesApiRequests.apiGet);
app.delete('/api/requests', routesApiRequests.apiDelete);

app.get('/api/elements', routesApiElements.apiGet);

app.all('*', function(req, res){
  res.render('404');
  //res.status(404).send();
})

// development only
if ('development' == app.get('env')) {
  app.use(errorHandler());
}
http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});
