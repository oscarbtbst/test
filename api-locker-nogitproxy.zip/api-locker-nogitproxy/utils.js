var request = require('request');
var crypto = require('crypto');

/**
 * generates random string of characters i.e salt
 * @function
 * @param {number} length - Length of the random string.
 */
var genRandomString = function(length){
    return crypto.randomBytes(Math.ceil(length/2))
            .toString('hex') /** convert to hexadecimal format */
            .slice(0,length);   /** return required number of characters */
};

/**
 * hash password with sha512.
 * @function
 * @param {string} password - List of required fields.
 * @param {string} salt - Data to be validated.
 */
var sha512 = function(password, salt){
    var hash = crypto.createHmac('sha512', salt); /** Hashing algorithm sha512 */
    hash.update(password);
    var value = hash.digest('hex');
    return {
        salt:salt,
        passwordHash:value
    };
};

exports.saltHashPassword = function(userpassword) {
    var salt = '1234567890123456'; /** Gives us salt of length 16 */
    return sha512(userpassword, salt).passwordHash;
}

exports.sendGetRequest = function(url, data) {
  return new Promise(resolve => {
    console.log('GET url: ' + url + ', data:');
    console.log(JSON.stringify(data, null, 2));
    var proxiedRequest = request.defaults({proxy: process.env.http_proxy});
    proxiedRequest.get(url, data, (error, response, body) => {
      if (error)
        resolve({error: error});
      else if (response.statusCode == 200 )
        resolve(response.body);
      else
        resolve(response);
    })
  });
}

exports.sendPutRequest = function(url, data) {
  return new Promise(resolve => {
    console.log('PUT url: ' + url + ', data:');
    console.log(JSON.stringify(data, null, 2));
    var proxiedRequest = request.defaults({proxy: process.env.http_proxy});
    proxiedRequest.put({url: url, form: data.json, headers: data.headers}, (error, response, body) => {
      if (error)
        resolve({error: error});
      else if (response.statusCode == 200 )
        resolve(response.body);
      else
        resolve(response);
    })
  });
}

exports.sendPostRequest = function(url, data) {
  return new Promise(resolve => {
    console.log('POST url: ' + url + ', data:');
    console.log(JSON.stringify(data, null, 2));
    var proxiedRequest = request.defaults({proxy: process.env.http_proxy});
    proxiedRequest.post({url: url, form: data.json, headers: data.headers}, (error, response, body) => {
      if (error)
        resolve({error: error});
      else if (response.statusCode == 200 )
        resolve(response.body);
      else
        resolve(response);
    })
  });
}

exports.httpResend = function(req, res, url, options) {
  //Check token client and get ratings
  if (!req.body || !req.body.token)
    return res.json({error: 'No data provided.'});

  var selector = {token: req.body.token};
  req.db.Clients.findOne({where: selector}).then(client => {

    if (client) {

      var data = options;
      if (client.profile === 'Admin' && req.body.url && req.body.data) {

        url = req.body.url;
        data = JSON.parse(req.body.data);
        exports.sendGetRequest(url, data).then(response => {
          return res.json(response);
        });
      }
      else
        exports.sendRequest(url, data).then(response => {
          return res.json(response);
        });

    }
    else
      return res.json({});
  });
}
