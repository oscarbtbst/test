# api-ratings

Api para la gestión de ratings de apps

## Requerimientos
- Tener un servidor MongoDB arrancado en la máquina local

## Instalación mySQL en CentOS
- Mediante repositorio YUM
```
wget https://dev.mysql.com/get/mysql80-community-release-el7-3.noarch.rpm
md5sum mysql80-community-release-el7-3.noarch.rpm
sudo rpm -ivh mysql80-community-release-el7-3.noarch.rpm
sudo yum install mysql-server
sudo systemctl start mysqld
sudo systemctl status mysqld
grep 'temporary password' /var/log/mysqld.log
sudo mysql -u root -p
```

## Instalación nodeJS en CentOS
- Mediante repositorio YUM
```
curl -sL https://rpm.nodesource.com/setup_10.x | sudo bash -
sudo yum install nodejs
```

- Mediante gestor versiones node NVM
```
curl -o- https://raw.githubusercontent.com/creationix/nvm/v0.33.11/install.sh | bash
nvm --version
nvm install node
nvm ls
```

## Comprobación instalación nodeJS
```
node --version
npm --version
```

## Arranque aplicación
- Clonar la aplicación mediante el comando:
```
git clone https://oscarbtbst2@bitbucket.org/oscarbtbst2/api-ratings.git
```
- Instalar los módulos necesarios y arrancar la aplicación:
```
npm install
npm start
```
- Abrir puerto 3000 en CentOS7
```
sudo firewall-cmd --zone=public --permanent --add-port=3000/tcp
sudo firewall-cmd --reload
```
## Testeo API
- Testeo de la API de la aplicación mediante el comando:
```
mocha ./test/ratings.js
```
- Rendimiento de la API de la aplicación mediante el comando:
```
mocha --timeout 30000 ./test/performance.js
```

## Diseño API

#### Apps que utilizarán el API
  - miOficina: fc55ff78f4a3b0d1bc70aedcc4aadc53ae7575ea201e647d3a23a846b82423d921b784ba45fc8da421437daec422ea0e
  - migracionGo: 3b6833d86a866c28304a928cc61390c7eb11c24553164a55ebd32353c6a4b849ad532aad077a22b28bb363343ae3a10d
  - concentracionGo: ab37588d08c06ca050686059af4296a088f6302dd36839916051290eb87b7496fa35f0fd1eeed56828c05aeec8dc77a5
  - Support Corner: 4c8dfe2976471aba7c30a0466c75467537435af39f9a59459e41081077d64d4187a788a9035239804bc94ba2c42c9f20
  - Support Corner Fix: 25cd20a3475a4252478dbe57b46afcdfbae8808090cc5430db9ab6113e0090abb297092e20b881103b049b1aefe9c5f3
  - Minerva: 8781d9a08259bb35c002985e4ed7a15660b2146907421ca3549c1193ccbd015afbe65daac1e4e0e554809e4906e8c1d9
  - ABCScanner: 29b942bd19d8af01229199a5896ae745f44182428845c5b305e56d8b545f458bd9c637bf64c538db4b59d2b6c2791e4c

#### FIXED token
  - ce83b2f98deda9a8605a58b056976ca55e860063ac51d67a523c03f4bbca2416b9179b0b7dc6d7a556fd3faad4408e1e

#### POST /api/clients/register
  - IN: body.name
  - IN: body.password
  - IN: profile: String
  - IN: profileApps: String
  - OUT: client
#### GET /api/clients/login
  - IN: body.name
  - IN: body.password
  - OUT: token
  - OUT: affectedRows
#### GET /api/clients/logout
  - IN: body.token
  - OUT: affectedRows
#### POST /api/ratings
  - IN: body.token
  - IN: body.user
  - IN: body.appName
  - IN: body.version
  - IN: body.value
  - IN: body.comment
  - OUT: rating
  - OUT: affectedRows
#### DEL /api/ratings
  - IN: body.token
  - IN: body.id
  - OUT: affectedRows
#### GET /api/ratings
  - IN: body.token
  - IN (optional): body.appName
  - IN (optional): body.version
  - IN (optional): body.limit
  - OUT: body.array of
    - user
    - appName
    - version
    - value
    - comment
    - clientName
    - ratingId

## Diseño base de datos

### clients
- id: AUTOINCREMENT
- createdAt: Date
- updatedAt: Date
- name: String
- password: String
- token: String
- profile: String
- profileApps: String

### ratings
- id: AUTOINCREMENT
- createdAt: Date
- updatedAt: Date
- user: String
- comment: String
- value: Number
- clientName: String
- appName: String
- version: String
