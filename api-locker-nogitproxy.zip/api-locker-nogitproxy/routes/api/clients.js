var utils = require('../../utils');

exports.apiRegister = function(req, res, next){
  //TODO: Check user not exists and create and login
  if (!req.body || !req.body.name || !req.body.password || !req.body.tokenFixed)
    return res.json({error: 'No data provided.'});

  var selector = {
    token: req.body.tokenFixed
  };

  req.db.Clients.findOne({where: selector}).then(client => {
    if (client && client.name === 'FIXED') {

      req.crypto.randomBytes(48, function(err, buffer) {
        var token = buffer.toString('hex');
        var saltPassword = utils.saltHashPassword(req.body.password);

        req.db.Clients
          .findOrCreate({
            where: {name: req.body.name},
            defaults: {
              password: saltPassword,
              token: token
            }
          })
          .then(([client, created]) => {

            let result = {affectedRows: 0};
            let promises = [];
            if (req.body.profile && req.body.profile !== client.profile) {
              client.profile = req.body.profile;
              promises.push(req.db.Clients.update({profile: client.profile}, {where: {id: client.id}}));
            }
            if (req.body.profileApps && req.body.profileApps !== client.profileApps) {
              client.profileApps = req.body.profileApps;
              promises.push(req.db.Clients.update({profileApps: client.profileApps}, {where: {id: client.id}}));
            }
            if (saltPassword !== client.password) {
              promises.push(req.db.Clients.update({password: saltPassword}, {where: {id: client.id}}));
            }

            Promise.all(promises).then(results => {

              if (results.length > 0)
                result.affectedRows = 1;
              result.client = client;

              return res.json(result);
            });
          });
      });
    }
    else
      return res.json({});
  });
};


exports.apiLogin = function(req, res, next){
  //TODO: Check user not exists and login
  if (!req.body || !req.body.name || !req.body.password)
    return res.json({error: 'No data provided.'});

  req.crypto.randomBytes(48, function(err, buffer) {

    var selector = {
      name: req.body.name,
      password: utils.saltHashPassword(req.body.password)
    };

    req.db.Clients.findOne({where: selector})
      .then(client => {
        if (client) {

          if (client.token)
            token = client.token
          else
            token = buffer.toString('hex');

          //Only can web login user profiles
          if (['Admin', 'Manager', 'Reader'].includes(client.profile)) {
            req.session.token = token;
            req.session.name = client.name;
            req.session.profile = client.profile;
            req.session.profileApps = client.profileApps;
          }

          if (client.token)
            return res.json({affectedRows: 0, token: token})
          else {
            req.db.Clients.update({token: token}, {where: selector}).then(affectedRows => {
              return res.json({affectedRows: affectedRows[0], token: token});
            });
          }
        }
        else
          return res.json({});
      });
  });
};

exports.apiLogout = function(req, res, next){
  //Remove token
  console.log('removeToken');
  if (!req.body || !req.body.token)
    return res.json({error: 'No data provided.'});

  var selector = {
    token: req.body.token
  };
  req.db.Clients.update({token: ''}, {where: selector}).then(affectedRows => {
    return res.json({affectedRows: affectedRows[0]});
  });
};

exports.apiToken = function(req, res, next){
  //Change token
  if (!req.body || !req.body.tokenFixed || !req.body.tokenOld || !req.body.tokenNew)
    return res.json({error: 'No data provided.'});

  var selector = {
    token: req.body.tokenFixed
  };

  req.db.Clients.findOne({where: selector}).then(client => {
    if (client && client.name === 'FIXED') {
      var selector = {
        token: req.body.tokenOld
      };
      req.db.Clients.update({token: req.body.tokenNew}, {where: selector}).then(affectedRows => {
        return res.json({affectedRows: affectedRows[0]});
      });
    }
  });
};
