const modelCore = require('../../model/core');
const utils = require('../../utils');

exports.apiGet = function(req, res, next){
  if (Object.keys(req.query).length > 0)
    req.body = req.query;
  //Check token client and get requests
  if (!req.body || !req.body.token)
    return res.json({error: 'No data provided.'});

  var selector = {token: req.body.token};
  req.db.Clients.findOne({where: selector}).then(client => {

    if (client) {
      selector = {clientName: client.name};
      if (req.body.appName)
        selector.appName = req.body.appName;
      if (req.body.parameters)
        selector.parameters = req.body.parameters;

      var query = {
        where: selector,
        order: [['updatedAt', 'DESC']]
      };

      if (req.body.limit && parseInt(req.body.limit))
        query.limit = parseInt(req.body.limit);

      req.db.Requests.findAll(query).then(requests => {
        return res.json(requests);
      });
    }
    else
      return res.json({});
  });
};


exports.apiPost = async function(req, res, next){
  if (Object.keys(req.query).length > 0)
    req.body = req.query;
  //Check token user and publish request, creating or updating depending if exists by type and parameters
  if (!req.body || !req.body.type || !req.body.parameters || !req.body.value)
    return res.json({error: 'No data provided.'});

  var selector = {token: req.body.token};
  var client = await modelCore.getClient(selector);

  if (client) {
    var request_config = await modelCore.getConfigValue(req.body.type);
    selector = {clientName: client.name, type: req.body.type, parameters: req.body.parameters};
    var appName = client.name;

    if (request_config) {
      var requests_simulation = await modelCore.getConfigValue('requests_simulation');
      var endPointType = req.body.type.split("#")[0];
      var endPointPath = req.body.type.split("#")[1];
      var params = request_config.split('#')[0];
      var json = {};
      params.split(';').forEach((param, idx) => {
        if (idx == 0 && endPointPath.split(':').length == 2)
          endPointPath = endPointPath.split(':')[0] + req.body.parameters.split(';')[idx]
        else {
          var value = req.body.parameters.split(';')[idx];
          if (value === 'false')
            value = false
          else if (value === 'true')
            value = true;
          //Si param contiene caracter punto, crear json
          if (param.indexOf('.') > 0) {
            if (!param.split('.')[0])
              json[param.split('.')[0]] = {};
            json[param.split('.')[0]][param.split('.')[1]] = value;
          }
          else
            json[param] = value;
        }
      });

      var url = await modelCore.getConfigValue('url');
      var data = {json: json};
      var basic_auth = await modelCore.getConfigValue('basic_auth');
      if (basic_auth.indexOf('Basic') == 0)
        data.headers = {Authorization: basic_auth}
      else {
        var username = await modelCore.getConfigValue('username');
        var password = await modelCore.getConfigValue('password');
        data.headers = {username: username, password: password};
      }

      var response = {error: "No response"};
      if (requests_simulation === 'true') {
        console.log('SIMULATION REQUEST: ' + url);
        console.log(data);
        if (request_config.indexOf('#') >= 0)
          response = JSON.parse(request_config.split('#')[1]);
      }
      else if (endPointType === 'GET')
        response = await utils.sendGetRequest(url, data)
      else if (endPointType === 'POST')
        response = await utils.sendPostRequest(url, data)
      else if (endPointType === 'PUT')
        response = await utils.sendPutRequest(url, data);
      console.log(response);

      var defaults = {
        response: JSON.stringify(response),
        parameters: req.body.parameters,
        value: req.body.value,
        appName: appName
      };

      req.db.Requests
        .findOrCreate({
          where: selector,
          defaults: defaults
        })
        .then(([request, created]) => {
          if (!created) {
            req.db.Requests.update(defaults, {where: selector}).then(affectedRows => {
                return res.json({affectedRows: affectedRows[0], request: request, response: response});
            });
          }
          else
            return res.json({affectedRows: 1, request: request, response: response});
        })

    }
    else
      return res.json({error: 'No config: ' + req.body.user});
  }
  else
    return res.json({error: 'No client provided.'});
};


exports.apiDelete = function(req, res, next){
  //Check token client and delete request by id
  if (!req.body || !req.body.id || (!req.body.token && !req.session.token))
    return res.json({error: 'No data provided.'});

  var token = req.body.token
  if (req.session.token)
    token = req.session.token;
  var selector = {token: token};
  req.db.Clients.findOne({where: selector}).then(client => {

    if (client) {
      selector = {id: req.body.id};
      if (client.profile === 'App')
        selector.clientName = client.name;

      req.db.Requests
        .destroy({where: selector})
        .then((affectedRows) => {
          return res.json({affectedRows: affectedRows});
        })
    }
    else
      return res.json({});

  });
};
