const utils = require('../../utils');

exports.apiGet = function(req, res, next) {
  var url = 'http://192.168.43.154:8080/api/ratings';
  var options = {
    token: 'fc55ff78f4a3b0d1bc70aedcc4aadc53ae7575ea201e647d3a23a846b82423d921b784ba45fc8da421437daec422ea0e'
  }
  return utils.httpResend(req, res, url, options);
}