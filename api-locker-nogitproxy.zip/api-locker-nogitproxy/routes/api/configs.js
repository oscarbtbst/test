const modelCore = require('../../model/core');

exports.apiPutConfigs = async function(req, res, next){
  //Change configuration
  if (!req.body || !req.body.tokenFixed || !req.body.key || !req.body.value)
    return res.json({error: 'No data provided.'});

  var selector = {
    token: req.body.tokenFixed
  };
  var client = await modelCore.getClient(selector);
  if (client && client.name === 'FIXED') {
    var selector = {
      key: req.body.key
    };
    req.db.Configs.update({value: req.body.value}, {where: selector}).then(affectedRows => {
      return res.json({affectedRows: affectedRows[0]});
    });
  }
};

exports.apiGetConfigs = async function(req, res, next){
  //Change configuration
  if (!req.body || !req.body.tokenFixed || !req.body.key)
    return res.json({error: 'No data provided.'});

  var selector = {
    token: req.body.tokenFixed
  };
  var client = await modelCore.getClient(selector);
  if (client && client.name === 'FIXED') {
    var selector = {
      key: req.body.key
    };
    req.db.Configs.findOne({where: {key: req.body.key}}).then(config => {
      var result = {config: config};
      if (result.config.value.indexOf('#') >= 0)
        result.response = JSON.parse(result.config.value.split('#')[1]);
      return res.json(result);
    });
  }
};
