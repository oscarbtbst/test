const pjson = require('../../package.json');
const modelCore = require('../../model/core');

exports.sessions = function(req, res){
  //Change token
  if (!req.body || !req.body.tokenFixed)
    return res.json({error: 'No data provided.'});

  var selector = {
    token: req.body.tokenFixed
  };

  req.db.Clients.findOne({where: selector}).then(client => {
    if (client && client.name === 'FIXED') {
      let selector = {
      };
      req.db.Sessions.findAll({where: selector}).then(sessions => {
        let webSessions = [];
        sessions.forEach(session => {
          session.data = JSON.parse(session.data);
          if (session.data.name)
            webSessions.push(session);
        });
        return res.json(webSessions);
      });
    }
  });
}

exports.api = function(req, res) {
  if (!req.body || !req.body.tokenFixed)
    return res.json({error: 'No data provided.'});

  var selector = {
    token: req.body.tokenFixed
  };

  req.db.Clients.findOne({where: selector}).then(client => {
    if (client && client.name === 'FIXED') {
      return res.json({
        api: {
          name: pjson.name,
          version: pjson.version,
          version_description: pjson.version_description,
          environment: environment,
          http_proxy: process.env.http_proxy || 'empty',
          clients: {
            register: {
              POST: {
                body: {
                  name: 'String',
                  password: 'String',
                  profile: 'String',
                  profileApps: 'String',
                  tokenFixed: 'String'
                },
                out: {
                  client: 'Object',
                  affectedRows: 'Integer'
                }
              }
            },
            login: {
              GET: {
                body: {
                  name: 'String',
                  password: 'String'
                },
                out: {
                  token: 'String',
                  affectedRows: 'Integer'
                }
              }
            },
            logout: {
              GET: {
                body: {
                  token: 'String'
                },
                out: {
                  affectedRows: 'Integer'
                }
              }
            },
            token: {
              PUT: {
                body: {
                  tokenFixed: 'String',
                  tokenOld: 'String',
                  tokenNew: 'String'
                },
                out: {
                  affectedRows: 'Integer'
                }
              }
            }
          },
          requests: {
            POST: {
              body: {
                token: 'String',
                user: 'String',
                appName: 'String',
                version: 'String',
                value: 'Integer',
                comment: 'String'
              },
              out: {
                request: 'Object',
                affectedRows: 'Integer'
              }
            },
            DELETE: {
              body: {
                token: 'String',
                id: 'Integer'
              },
              out: {
                affectedRows: 'Integer'
              }
            },
            GET: {
              body: {
                token: 'String',
                appName: 'String',
                version: 'String',
                limit: 'Integer'
              },
              out: {
                requests: 'Array of Object'
              }
            }
          }
        }
      });
    }
    else
      return res.json({});
  });
};
