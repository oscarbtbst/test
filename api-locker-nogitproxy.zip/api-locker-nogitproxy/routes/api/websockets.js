const pjson = require('../../package.json');
const modelCore = require('../../model/core');
const moment = require('moment');

exports.apiLogsWebsocket = async function(req, res, next){
  if (!req.body || !req.body.tokenFixed)
    return res.json({error: 'No data provided.'});

  var selector = {
    token: req.body.tokenFixed
  };
  var client = await modelCore.getClient(selector);
  if (client && client.name === 'FIXED') {
    return res.json(websocketLogs);
  }
}

exports.apiMessageWebsocket = async function(req, res, next){
  if (!req.body || !req.body.tokenFixed || !req.body.identifier || !req.body.data)
    return res.json({error: 'No data provided.'});

  var selector = {
    token: req.body.tokenFixed
  };
  var client = await modelCore.getClient(selector);
  if (client && client.name === 'FIXED') {
    var msg = {
      command: 'message',
      identifier: req.body.identifier,
      data: req.body.data
    };
    wsConnection.send(JSON.stringify(msg));
    return res.json(msg);
  }
}

exports.apiSubscribeWebsocket = async function(req, res, next){
  if (!req.body || !req.body.tokenFixed || !req.body.identifier)
    return res.json({error: 'No data provided.'});

  var selector = {
    token: req.body.tokenFixed
  };
  var client = await modelCore.getClient(selector);
  if (client && client.name === 'FIXED') {
    var msg = {
      command: 'subscribe',
      identifier: req.body.identifier
    };
    wsConnection.send(JSON.stringify(msg));
    return res.json(msg);
  }
}

exports.apiPut = async function(req, res, next){
  if (!req.body || !req.body.tokenFixed || !req.body.payload)
    return res.json({error: 'No data provided.'});

  var selector = {
    token: req.body.tokenFixed
  };
  var client = await modelCore.getClient(selector);
  if (client && client.name === 'FIXED') {
    wsConnection.send(req.body.payload);
    return res.json(req.body.payload);
  }
}

exports.apiDelete = async function(req, res, next){
  if (!req.body || !req.body.tokenFixed)
    return res.json({error: 'No data provided.'});

  var selector = {
    token: req.body.tokenFixed
  };
  var client = await modelCore.getClient(selector);
  if (client && client.name === 'FIXED') {
    wsConnection.close();
    return res.json({msg: 'Websocket disconnecting'});
  }
}

websocketLogs = [];

exports.apiGet = async function(req, res, next){
  if (!req.body || !req.body.tokenFixed || !req.body.endpoint)
    return res.json({error: 'No data provided.'});

  var selector = {
    token: req.body.tokenFixed
  };
  var client = await modelCore.getClient(selector);
  if (client && client.name === 'FIXED') {
    const url = require('url');
    const WebSocket = require('ws');
    const HttpsProxyAgent = require('https-proxy-agent');
    const endpoint = req.body.endpoint;

    if (process.env.http_proxy) {
      var options = url.parse(process.env.http_proxy);
      var agent = new HttpsProxyAgent(options);
      wsConnection = new WebSocket(endpoint, { agent: agent });
    }
    else
      wsConnection = new WebSocket(endpoint);

    wsConnection.onopen = () => {
      var msg = `WebSocket connected!`;
      websocketLogs.push({
        date: moment().format('DD/MM/YYYY HH:mm:ss'),
        msg: msg
      });
      console.log(msg);

      wsConnection.send('Message From Client');
    }

    wsConnection.onerror = (error) => {
      var msg = JSON.stringify(error);
      websocketLogs.push({
        date: moment().format('DD/MM/YYYY HH:mm:ss'),
        msg: 'Websocket error',
        event: error
      });
      console.log(`WebSocket error: ${msg}`)
    }

    wsConnection.onmessage = (e) => {
      console.log(e.data);
      var eventdata = JSON.parse(e.data);

      if (eventdata.type === 'welcome') {
        websocketLogs.push({
          date: moment().format('DD/MM/YYYY HH:mm:ss'),
          msg: e.data
        });
        /*
        var msg = {
          command: 'subscribe',
          identifier: JSON.stringify({
            channel: 'MachineChannel',
            ref: 'TEST1'
          })
        };
        wsConnection.send(JSON.stringify(msg));
        */
      }
      else if (eventdata.type === 'ping') {
      }
      else if (eventdata.type === 'confirm_subscription') {
        websocketLogs.push({
          date: moment().format('DD/MM/YYYY HH:mm:ss'),
          msg: e.data
        });
        /*
        var msg = {
          command: 'message',
          identifier: JSON.stringify({
            channel: 'MachineChannel',
            action: 'stay_alive',
            ref: 'TEST1'
          }),
          data: JSON.stringify({
            action: 'stay_alive'
          }),
        };
        console.log(JSON.stringify(msg));
        wsConnection.send(JSON.stringify(msg));
        */
      }
      else {
        websocketLogs.push({
          date: moment().format('DD/MM/YYYY HH:mm:ss'),
          msg: e.data
        });
      }
    }
    wsConnection.onclose = (e) => {
      var msg = `WebSocket disconnected!`;
      websocketLogs.push({
        date: moment().format('DD/MM/YYYY HH:mm:ss'),
        msg: msg,
        event: e
      });
      console.log(`WebSocket disconnected: ${msg}`)
    }
    return res.json({msg: 'Websocket connecting'})
  }
}

exports.apiDeleteActioncable = async function(req, res, next){
  if (!req.body || !req.body.tokenFixed)
    return res.json({error: 'No data provided.'});

  var selector = {
    token: req.body.tokenFixed
  };
  var client = await modelCore.getClient(selector);
  if (client && client.name === 'FIXED') {
    wsCable.close();
    return res.json({msg: 'Websocket Actioncable disconnecting'});
  }
  else
    return res.json({error: 'No client provided.'})
}

exports.apiGetActioncable = async function(req, res, next){
  if (!req.body || !req.body.tokenFixed ||
    !req.body.endpoint || !req.body.channel || !req.body.function)
    return res.json({error: 'No data provided.'});

  var selector = {
    token: req.body.tokenFixed
  };
  var client = await modelCore.getClient(selector);
  if (client && client.name === 'FIXED') {
    const ActionCable = require('actioncable');

    let cable_url = req.body.endpoint;

    wsCable = new ActionCable(cable_url,{
      // If you validate the origin on the server, you can set that here
      origin: cable_url/*,

      // Using headers with an API key for auth is recommended
      // because we dont have the normal browser session to authenticate with
      headers: {
        'X-Api-Key': 'someexampleheader'
      }*/
    });

    let subscription = wsCable.subscribe(req.body.channel, {
      connected() {
        websocketLogs.push({
          date: moment().format('DD/MM/YYYY HH:mm:ss'),
          msg: "Actioncable connected"
        });
        var data_function;
        if (req.body.data_function)
          data_function = JSON.parse(req.body.data_function);
        subscription.perform(req.body.function, data_function);
      },

      disconnected() {
        websocketLogs.push({
          date: moment().format('DD/MM/YYYY HH:mm:ss'),
          msg: "Actioncable disconnected"
        });
      },

      rejected() {
        websocketLogs.push({
          date: moment().format('DD/MM/YYYY HH:mm:ss'),
          msg: "Actioncable rejected"
        });
      },

      received(data) {
        websocketLogs.push({
          date: moment().format('DD/MM/YYYY HH:mm:ss'),
          msg: "Actioncable received",
          data: data
        });
      }
    });

    // Send a message to the server
    //subscription.perform("stay_alive", {foo: 'bar'});
    //!!!!subscription.perform(req.body.function);
    return res.json({msg: 'Websocket Actioncable connecting'})
  }
  else
    return res.json({error: 'No client provided.'})
}
