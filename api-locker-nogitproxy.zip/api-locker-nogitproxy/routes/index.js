var utils = require('../utils');
var moment = require('moment');
var Op = require('sequelize').Op;

exports.login = function(req, res){
  return res.render('login');
};

exports.logout = function(req, res){
  req.session.token = '';
  return res.render('login');
};

exports.index = function(req, res){

  if (!req.session.token)
    return res.redirect('login');
  else {
    var selector = {token: req.session.token};
    req.db.Clients.findOne({where: selector}).then(client => {

      if (!client)
        return res.redirect('login');

      var selector = {};
      if (req.body.type)
        selector.type = {[Op.like]: '%' + req.body.type + '%'};
      if (req.body.parameters)
        selector.parameters = {[Op.like]: '%' + req.body.parameters + '%'};
      if (req.body.appname)
        selector.appName = {[Op.like]: '%' + req.body.appname + '%'};
      if (req.body.response)
        selector.response = {[Op.like]: '%' + req.body.response + '%'};
      if (req.body.datestart) {
        var dateStart = moment(req.body.datestart, 'YYYY-MM-DD').toDate();
        var dateEnd = moment(dateStart).add(1, 'days').toDate();
        if (req.body.dateend)
          dateEnd = moment(req.body.dateend, 'YYYY-MM-DD').add(1, 'days').toDate();
        selector.updatedAt = {[Op.gte]: dateStart, [Op.lt]: dateEnd};
      }
      if (req.session.profileApps)
        selector.clientName = req.session.profileApps.split(',');

      req.db.Requests.findAll({
        where: selector,
        order: [['updatedAt', 'DESC']],
        limit: 50
      }).then(requests => {
        requests.forEach(request => {
          request.dateText = moment(request.updatedAt).format('DD/MM/YYYY hh:mm:ss');
        });
        if (req.method == "POST") {
          return res.render('./tables/tablerequests', {
            title: 'Requests',
            user: {
              name: req.session.name + '    ',
              profile: req.session.profile
            },
            requests: requests || []
          })
        }
        else
          return res.render('index', {
            title: 'Requests',
            user: {
              name: req.session.name + '    ',
              profile: req.session.profile
            },
            requests: requests || []
          });
      });
    });
  }
};

exports.clients = function(req, res){

  if (!req.session.token)
    return res.redirect('login');
  else {
    var selector = {token: req.session.token};
    req.db.Clients.findOne({where: selector}).then(client => {

      if (!client)
        return res.redirect('login');

      selector = {};
      if (req.body.name)
        selector.name = {[Op.like]: '%' + req.body.name + '%'};
      if (req.body.profile)
        selector.profile = {[Op.like]: '%' + req.body.profile + '%'};

      req.db.Clients.findAll({
        where: selector,
        order: [['updatedAt', 'DESC']]
      }).then(clients => {
        clients.forEach(client => {
          client.dateText = moment(client.updatedAt).format('DD/MM/YYYY hh:mm:ss');
        });
        if (req.method == "POST")
          return res.render('./tables/tableclients', {
            title: 'Clients',
            clients: clients || []
          })
        else
          return res.render('clients', {
            title: 'Clients',
            user: {
              name: req.session.name + '    ',
              profile: req.session.profile
            },
            clients: clients || []
          });
      });
    });
  }

};
