const modelCore = require('../model/core');
const utils = require('../utils');
const moment = require('moment');
const Op = require('sequelize').Op;
const locale = require('../views/js/locale/es');

exports.configs = async function(req, res){

  if (!req.session.token)
    return res.redirect('login')
  else if (['Admin'].indexOf(req.session.profile) < 0)
    res.render('404')
  else {
    var selector = {token: req.session.token};
    var client = await modelCore.getClient(selector);
    if (!client)
      return res.redirect('login');

    selector = {};
    if (req.body.key)
      selector.key = {[Op.like]: '%' + req.body.key + '%'};
    if (req.body.value)
      selector.value = {[Op.like]: '%' + req.body.value + '%'};

    req.db.Configs.findAll({
      where: selector,
      order: [['updatedAt', 'DESC']]
    }).then(configs => {
      configs.forEach(config => {
        config.dateText = moment(config.updatedAt).format('DD/MM/YYYY HH:mm:ss');
      });
      if (req.method == "POST") {
        return res.render('./tables/tableconfigs', {
          locale: locale(),
          user: {
            name: req.session.name + '    ',
            profile: req.session.profile
          },
          elems: configs || []
        })
      }
      else
        return res.render('configs', {
          option: "configs",
          locale: locale(),
          user: {
            name: req.session.name + '    ',
            profile: req.session.profile
          },
          elems: configs || []
        });
    });
  }

};
