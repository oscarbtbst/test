const Sequelize = require('sequelize');
const moment = require('moment');
const pjson = require('../package.json');

var os = require('os');
var ifaces = os.networkInterfaces();

var interfaces = [];
Object.keys(ifaces).forEach(function (ifname) {
  var alias = 0;

  ifaces[ifname].forEach(function (iface) {
    if ('IPv4' !== iface.family || iface.internal !== false) {
      // skip over internal (i.e. 127.0.0.1) and non-ipv4 addresses
      return;
    }

    if (alias >= 1) {
      // this single interface has multiple ipv4 addresses
      interfaces.push({
        name: ifname + ':' + alias,
        address: iface.address
      });
    }
    else {
      // this interface has only one ipv4 adress
      interfaces.push({
        name: ifname,
        address: iface.address
      });
    }
    ++alias;
  });
});

console.log(interfaces);
var dbhost = '';//pjson.config_env[pjson.environment].dbhost;
interfaces.forEach(interface => {
  if (interface.address) {
    Object.keys(pjson.config_env).forEach((env) =>{
      var arrAppHost = pjson.config_env[env].apphost.split(',');
      arrAppHost.forEach((apphost) => {
        if (interface.address.indexOf(apphost) == 0) {
          dbhost = pjson.config_env[env].dbhost;
          environment = env;
        }
      });
    });
  }
});

// Option 1: Passing parameters separately
const sequelize = new Sequelize(pjson.name.replace('-', ''), 'apiuser', 'mySQL,1853', {
  host: dbhost,
  dialect: 'mysql',
  logging: (msg) => console.log('[' + moment().format('DD/MM/YYYY HH:mm:ss') + '][DB] ' + msg)
});
exports.sequelize = sequelize;

sequelize
  .authenticate()
  .then(() => {
    console.log('Connection has been established successfully.');
  })
  .catch(err => {
    console.error('Unable to connect to the database:', err);
  });
