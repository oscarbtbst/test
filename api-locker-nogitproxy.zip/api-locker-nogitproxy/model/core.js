const Sequelize = require('sequelize');
const sequelize = require('./mySQL').sequelize;
const pjson = require('../package.json');

var initRegister = function(Table, key, defaults) {
  Table
    .findOrCreate({
      where: key,
      defaults: defaults
    })
    .then(([register, created]) => {
      //console.log(register);
    });
}

var initClients = function() {
  return sequelize.define('clients', {
    // attributes
    name: {
      type: Sequelize.STRING,
      allowNull: false
    },
    password: {
      type: Sequelize.STRING
    },
    token: {
      type: Sequelize.STRING
    },
    profile: {
      type: Sequelize.STRING
    },
    profileApps: {
      type: Sequelize.STRING
    }
  }, {
    // options
  });
}

var initRequests = function() {
  return sequelize.define('requests', {
    // attributes
    clientName: {
      type: Sequelize.STRING
    },
    type: {
      type: Sequelize.STRING
    },
    response: {
      type: Sequelize.TEXT
    },
    value: {
      type: Sequelize.INTEGER
    },
    appName: {
      type: Sequelize.STRING
    },
    parameters: {
      type: Sequelize.TEXT
    }
  }, {
    // options
  });
}

var Clients = initClients();
sequelize.sync();
sequelize.queryInterface.describeTable('clients').then(response => {

  var proColumns = [];
  if (!response.profile)
    proColumns.push(sequelize.queryInterface.addColumn('clients', 'profile', Sequelize.STRING));
  if (!response.profileApps)
    proColumns.push(sequelize.queryInterface.addColumn('clients', 'profileApps', Sequelize.STRING));

  Promise.all(proColumns).then(values => {

    Clients = initClients();

    Clients
      .findOrCreate({
        where: {name: 'FIXED'},
        defaults: {
          password: 'FIXED',
          token: 'ce83b2f98deda9a8605a58b056976ca55e860063ac51d67a523c03f4bbca2416b9179b0b7dc6d7a556fd3faad4408e1e'
        }
      })
      .then(([user, created]) => {
        console.log(user.get({
          plain: true
        }))
        console.log(created)
      })

    sequelize.sync();
    exports.dbclients = Clients;
  });
});

var Requests = initRequests();
sequelize.sync();
sequelize.queryInterface.describeTable('requests').then(response => {

  Requests = initRequests();
  sequelize.sync();
  exports.dbrequests = Requests;
});

const Sessions = sequelize.define('Sessions', {
  sid: {
    type: Sequelize.STRING,
    primaryKey: true
  },
  expires: Sequelize.DATE,
  data: Sequelize.TEXT
});
exports.dbsessions = Sessions;

const Configs = sequelize.define('configs', {
  // attributes
  key: {
    type: Sequelize.STRING,
    primaryKey: true
  },
  value: {
    type: Sequelize.TEXT
  }
}, {
  // options
});
exports.dbconfigs = Configs;

exports.getConfigValue = function(key) {
  return new Promise(resolve => {
    Configs.findOne({raw: true, where: {key: key}}).then(config => {
      if (config)
        resolve(config.value)
      else
        resolve('');
    });
  });
}

exports.getClient = function(selector) {
  return Clients.findOne({raw: true, where: selector});
}

initRegister(Configs, {key: 'requests_simulation'}, {value: 'false'});
if (pjson.name === 'api-locker') {
  initRegister(Configs, {key: 'url'}, {value: 'http://iecisa.drop-point.com/company_api/v3/'});
  initRegister(Configs, {key: 'username'}, {value: 'abelias@abelias.com'});
  initRegister(Configs, {key: 'password'}, {value: 'abelias@abelias.com'});
  initRegister(Configs, {key: 'basic_auth'}, {value: 'false'});

  initRegister(Configs, {key: 'GET#shipment'}, {value: 'rpm_code#{"success":true,"shipment":{"rpm_code":"646864844","locker_id":"ABELIAS","user_inquire":"X314915","box_size":"S","delivery_key":"1234567890","client_key":"1234567890","revocation_key":"1234567890","state":"PREPA","milestones":{"created_at":"21-06-2016 11:43:10","delivered_at":"21-06-2016 11:53:31"}}}'});
  initRegister(Configs, {key: 'PUT#shipment'}, {value: 'rpm_code;state#{"success": true}'});
  initRegister(Configs, {key: 'POST#shipment'}, {value: 'locker_id;rpm_code;user_inquire;box_size;delivery_key;client_key;revocation_key#{"success": true}'});

  initRegister(Configs, {key: 'GET#free_boxes'}, {value: 'machine_ref#{"L":11,"M":4,"S":5}'});
  initRegister(Configs, {key: 'GET#shipments'}, {value: 'external_id#[{"id":22,"external_id":"33","user_inquire":"X314915","sender_key":"1234000000","picking_key":"2121212121","returning_key":"5678000000","delivered_at":"2019-11-05T15:30:53.550+01:00","picked_at":null,"returned_at":null,"created_at":"2019-11-05T13:49:33.409+01:00","updated_at":"2019-11-05T15:30:53.557+01:00","description":"","machine_ref":"ABELIAS","state":"CARGADO","box_name":"02","boz_size":"S"}]'});
  initRegister(Configs, {key: 'POST#shipments'}, {value: 'machine_ref;box_size;external_id;sender_key;picking_key;returning_key;user_inquire#{"id":22,"external_id":"33","user_inquire":"X314915","sender_key":"1234000000","picking_key":"2121212121","returning_key":"5678000000","delivered_at":"2019-11-05T15:30:53.550+01:00","picked_at":null,"returned_at":null,"created_at":"2019-11-05T13:49:33.409+01:00","updated_at":"2019-11-05T15:30:53.557+01:00","description":"","machine_ref":"ABELIAS","state":"CARGADO","box_name":"02","boz_size":"S"}'});
  initRegister(Configs, {key: 'PUT#update_by_external_id/:external_id'}, {value: 'external_id;state#{"id": 1,"external_id": "EXT_123","user_inquire": null,"sender_key": "0000000000","picking_key": "0000000001","returning_key": "0000000002","delivered_at": null,"picked_at": null,"returned_at": null,"created_at": "2019-10-21T10:01:34.980+02:00","updated_at": "2019-10-21T10:01:34.980+02:00","description": null,"machine_ref": "AZUL","state": "AUTORIZADO","box_name": "1","boz_size": "M"}'});
}
else if (pjson.name === 'api-servicenow') {
  initRegister(Configs, {key: 'url'}, {value: 'https://santandertest.service-now.com/api/now/v2/table/'});
  initRegister(Configs, {key: 'basic_auth'}, {value: 'Basic dXNlcl9zYW50ZWNfbWljb3JuZXI6dXNlcl9zYW50ZWNfbWljb3JuZXIjdGVzdA=='});
}
